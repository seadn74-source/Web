"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Code, Copy, Check } from "lucide-react"
import { toast } from "sonner"

export function ScriptPanel({ baseUrl }: { baseUrl: string }) {
  const [copied, setCopied] = useState(false)

  const luaScript = `-- GG Key System - Lua Script for Game Guardian
-- Paste this into your Game Guardian script

local BASE_URL = "${baseUrl || "https://your-domain.vercel.app"}"

function getHWID()
    local hwid = gg.getTargetInfo().packageName .. "_" .. 
                 tostring(gg.getTargetInfo().pid) .. "_" ..
                 (os.getenv("ANDROID_ID") or "unknown")
    return hwid
end

function verifyKey(key)
    local hwid = getHWID()
    local url = BASE_URL .. "/api/gg/verify?key=" .. key .. "&hwid=" .. hwid
    
    local response = gg.makeRequest(url)
    
    if response == nil then
        gg.alert("Connection error. Check your internet.")
        return false
    end
    
    local body = response.content
    
    if body == "KEY_VALID" or body == "KEY_ACTIVATED" then
        gg.toast("Key verified successfully!")
        return true
    elseif body == "KEY_NOT_FOUND" then
        gg.alert("Key not found!")
    elseif body == "KEY_EXPIRED" then
        gg.alert("Key has expired!")
    elseif body == "KEY_BANNED" then
        gg.alert("Key has been banned!")
    elseif body == "HWID_MISMATCH" then
        gg.alert("Key is bound to another device!")
    else
        gg.alert("Verification failed: " .. tostring(body))
    end
    
    return false
end

-- Main flow
gg.toast("GG Key System")
local key = gg.prompt({"Enter your key:"}, {""}, {"text"})

if key == nil then
    os.exit()
end

key = key[1]

if key == "" then
    gg.alert("Please enter a valid key!")
    os.exit()
end

local verified = verifyKey(key)

if verified then
    gg.alert("Access granted! Enjoy.")
    -- YOUR SCRIPT LOGIC GOES HERE
    -- Add your game hacking code below this line
    
else
    gg.alert("Access denied.")
    os.exit()
end`

  function copyScript() {
    navigator.clipboard.writeText(luaScript)
    setCopied(true)
    toast.success("Lua script copied to clipboard")
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="border-border/50 bg-card/60">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base font-mono">
            <Code className="w-4 h-4 text-primary" />
            Game Guardian Lua Script
          </CardTitle>
          <Button variant="outline" size="sm" onClick={copyScript} className="font-mono text-xs bg-transparent">
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 mr-1" />
                Copy Script
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg bg-secondary/50 border border-border/50 p-4 max-h-80 overflow-y-auto">
          <pre className="text-xs font-mono text-foreground/80 whitespace-pre-wrap">
            {luaScript}
          </pre>
        </div>
        <div className="mt-3 flex flex-col gap-1.5">
          <p className="text-xs text-muted-foreground">
            <strong className="text-foreground">API Endpoints:</strong>
          </p>
          <code className="text-xs font-mono text-primary bg-secondary/50 rounded px-2 py-1">
            GET /api/gg/verify?key=YOUR_KEY&hwid=DEVICE_HWID
          </code>
          <code className="text-xs font-mono text-primary bg-secondary/50 rounded px-2 py-1">
            POST /api/gg/verify {"{"} key, hwid {"}"}
          </code>
          <p className="text-xs text-muted-foreground mt-1">
            <strong className="text-foreground">Response codes:</strong>{" "}
            KEY_VALID, KEY_ACTIVATED, KEY_NOT_FOUND, KEY_EXPIRED, KEY_BANNED, HWID_MISMATCH
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
