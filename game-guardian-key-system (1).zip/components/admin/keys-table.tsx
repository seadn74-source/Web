"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Key, MoreHorizontal, Ban, RotateCcw, Trash2, Copy } from "lucide-react"
import { toast } from "sonner"
import { format } from "date-fns"

interface KeyData {
  id: number
  key_value: string
  device_hwid: string | null
  status: string
  note: string
  duration_days: number
  activated_at: string | null
  expires_at: string | null
  created_at: string
}

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    unused: "bg-chart-2/15 text-chart-2 border-chart-2/30",
    active: "bg-primary/15 text-primary border-primary/30",
    expired: "bg-chart-3/15 text-chart-3 border-chart-3/30",
    banned: "bg-destructive/15 text-destructive border-destructive/30",
  }

  return (
    <Badge variant="outline" className={`font-mono text-xs ${variants[status] || ""}`}>
      {status.toUpperCase()}
    </Badge>
  )
}

export function KeysTable({
  keys,
  onAction,
}: {
  keys: KeyData[]
  onAction: (id: number, action: string) => void
}) {
  function copyKey(key: string) {
    navigator.clipboard.writeText(key)
    toast.success("Key copied")
  }

  return (
    <Card className="border-border/50 bg-card/60">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-base font-mono">
          <Key className="w-4 h-4 text-primary" />
          Keys ({keys.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 hover:bg-transparent">
                <TableHead className="font-mono text-xs text-muted-foreground">Key</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground">Status</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground hidden md:table-cell">
                  HWID
                </TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground hidden lg:table-cell">
                  Duration
                </TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground hidden lg:table-cell">
                  Expires
                </TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground hidden md:table-cell">
                  Note
                </TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground w-10">
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {keys.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground font-mono text-sm">
                    No keys generated yet
                  </TableCell>
                </TableRow>
              ) : (
                keys.map((k) => (
                  <TableRow key={k.id} className="border-border/30 hover:bg-secondary/30">
                    <TableCell>
                      <button
                        onClick={() => copyKey(k.key_value)}
                        className="flex items-center gap-1.5 group"
                        type="button"
                      >
                        <code className="text-xs font-mono text-primary group-hover:text-primary/80">
                          {k.key_value}
                        </code>
                        <Copy className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={k.status} />
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className="text-xs font-mono text-muted-foreground truncate max-w-32 block">
                        {k.device_hwid ? k.device_hwid.substring(0, 16) + "..." : "-"}
                      </span>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      <span className="text-xs font-mono text-muted-foreground">
                        {k.duration_days >= 9999 ? "Lifetime" : `${k.duration_days}d`}
                      </span>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      <span className="text-xs font-mono text-muted-foreground">
                        {k.expires_at
                          ? format(new Date(k.expires_at), "dd/MM/yyyy")
                          : "-"}
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className="text-xs text-muted-foreground truncate max-w-24 block">
                        {k.note || "-"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                            <MoreHorizontal className="w-3.5 h-3.5" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-40">
                          <DropdownMenuItem onClick={() => copyKey(k.key_value)}>
                            <Copy className="w-3.5 h-3.5 mr-2" />
                            Copy Key
                          </DropdownMenuItem>
                          {k.status !== "banned" && (
                            <DropdownMenuItem onClick={() => onAction(k.id, "ban")}>
                              <Ban className="w-3.5 h-3.5 mr-2" />
                              Ban Key
                            </DropdownMenuItem>
                          )}
                          {k.status === "banned" && (
                            <DropdownMenuItem onClick={() => onAction(k.id, "unban")}>
                              <RotateCcw className="w-3.5 h-3.5 mr-2" />
                              Unban Key
                            </DropdownMenuItem>
                          )}
                          {k.device_hwid && (
                            <DropdownMenuItem onClick={() => onAction(k.id, "reset_hwid")}>
                              <RotateCcw className="w-3.5 h-3.5 mr-2" />
                              Reset HWID
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem
                            onClick={() => onAction(k.id, "delete")}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="w-3.5 h-3.5 mr-2" />
                            Delete Key
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
