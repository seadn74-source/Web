"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Key, Shield, Clock, Ban, Activity, Zap } from "lucide-react"

interface Stats {
  total_keys: number
  active_keys: number
  unused_keys: number
  expired_keys: number
  banned_keys: number
  total_verifications: number
  recent_activity: number
}

export function StatsCards({ stats }: { stats: Stats | null }) {
  const cards = [
    {
      label: "Total Keys",
      value: stats?.total_keys ?? 0,
      icon: Key,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Active",
      value: stats?.active_keys ?? 0,
      icon: Shield,
      color: "text-chart-2",
      bg: "bg-chart-2/10",
    },
    {
      label: "Unused",
      value: stats?.unused_keys ?? 0,
      icon: Clock,
      color: "text-chart-3",
      bg: "bg-chart-3/10",
    },
    {
      label: "Expired",
      value: stats?.expired_keys ?? 0,
      icon: Zap,
      color: "text-chart-4",
      bg: "bg-chart-4/10",
    },
    {
      label: "Banned",
      value: stats?.banned_keys ?? 0,
      icon: Ban,
      color: "text-destructive",
      bg: "bg-destructive/10",
    },
    {
      label: "24h Activity",
      value: stats?.recent_activity ?? 0,
      icon: Activity,
      color: "text-chart-5",
      bg: "bg-chart-5/10",
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((card) => (
        <Card key={card.label} className="border-border/50 bg-card/60">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`flex items-center justify-center w-9 h-9 rounded-lg ${card.bg}`}>
                <card.icon className={`w-4 h-4 ${card.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold font-mono text-foreground">
                  {card.value}
                </p>
                <p className="text-xs text-muted-foreground">{card.label}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
