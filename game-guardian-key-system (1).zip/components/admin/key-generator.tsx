"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Plus, Copy, Check } from "lucide-react"
import { toast } from "sonner"

export function KeyGenerator({ onKeysGenerated }: { onKeysGenerated: () => void }) {
  const [count, setCount] = useState("1")
  const [duration, setDuration] = useState("30")
  const [note, setNote] = useState("")
  const [generatedKeys, setGeneratedKeys] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)

  async function generateKeys() {
    setLoading(true)
    try {
      const res = await fetch("/api/admin/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          count: Number.parseInt(count),
          duration_days: Number.parseInt(duration),
          note,
        }),
      })
      const data = await res.json()
      if (data.success) {
        setGeneratedKeys(data.keys)
        toast.success(`Generated ${data.keys.length} key(s)`)
        onKeysGenerated()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error("Failed to generate keys")
    } finally {
      setLoading(false)
    }
  }

  function copyKey(key: string, index: number) {
    navigator.clipboard.writeText(key)
    setCopiedIndex(index)
    toast.success("Key copied to clipboard")
    setTimeout(() => setCopiedIndex(null), 2000)
  }

  function copyAll() {
    navigator.clipboard.writeText(generatedKeys.join("\n"))
    toast.success("All keys copied to clipboard")
  }

  return (
    <Card className="border-border/50 bg-card/60">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-base font-mono">
          <Plus className="w-4 h-4 text-primary" />
          Generate Keys
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">Count</Label>
            <Input
              type="number"
              min="1"
              max="100"
              value={count}
              onChange={(e) => setCount(e.target.value)}
              className="bg-secondary/50 border-border font-mono"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">Duration</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger className="bg-secondary/50 border-border font-mono">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 Day</SelectItem>
                <SelectItem value="7">7 Days</SelectItem>
                <SelectItem value="14">14 Days</SelectItem>
                <SelectItem value="30">30 Days</SelectItem>
                <SelectItem value="60">60 Days</SelectItem>
                <SelectItem value="90">90 Days</SelectItem>
                <SelectItem value="365">365 Days</SelectItem>
                <SelectItem value="9999">Lifetime</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">Note</Label>
            <Input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional note..."
              className="bg-secondary/50 border-border font-mono"
            />
          </div>
        </div>
        <Button
          onClick={generateKeys}
          disabled={loading}
          className="font-mono font-semibold"
        >
          {loading ? "Generating..." : "GENERATE KEYS"}
        </Button>

        {generatedKeys.length > 0 && (
          <div className="flex flex-col gap-2 mt-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground font-mono">
                Generated {generatedKeys.length} key(s)
              </span>
              {generatedKeys.length > 1 && (
                <Button variant="ghost" size="sm" onClick={copyAll} className="text-xs">
                  <Copy className="w-3 h-3 mr-1" />
                  Copy All
                </Button>
              )}
            </div>
            <div className="flex flex-col gap-1 max-h-48 overflow-y-auto">
              {generatedKeys.map((key, i) => (
                <div
                  key={key}
                  className="flex items-center justify-between px-3 py-2 rounded-md bg-secondary/50 border border-border/50"
                >
                  <code className="text-sm font-mono text-primary">{key}</code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyKey(key, i)}
                    className="h-7 w-7 p-0"
                  >
                    {copiedIndex === i ? (
                      <Check className="w-3.5 h-3.5 text-primary" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
