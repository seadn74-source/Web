"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { ScrollText } from "lucide-react"
import { format } from "date-fns"

interface LogData {
  id: number
  key_value: string
  device_hwid: string
  action: string
  ip_address: string
  success: boolean
  message: string
  created_at: string
}

export function LogsTable({ logs }: { logs: LogData[] }) {
  return (
    <Card className="border-border/50 bg-card/60">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-base font-mono">
          <ScrollText className="w-4 h-4 text-primary" />
          Activity Logs (Last 200)
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 hover:bg-transparent">
                <TableHead className="font-mono text-xs text-muted-foreground">Time</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground">Key</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground">Action</TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground hidden md:table-cell">
                  HWID
                </TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground hidden md:table-cell">
                  IP
                </TableHead>
                <TableHead className="font-mono text-xs text-muted-foreground">Result</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground font-mono text-sm">
                    No activity yet
                  </TableCell>
                </TableRow>
              ) : (
                logs.map((log) => (
                  <TableRow key={log.id} className="border-border/30 hover:bg-secondary/30">
                    <TableCell className="text-xs font-mono text-muted-foreground whitespace-nowrap">
                      {format(new Date(log.created_at), "dd/MM HH:mm:ss")}
                    </TableCell>
                    <TableCell>
                      <code className="text-xs font-mono text-primary">
                        {log.key_value.substring(0, 11)}...
                      </code>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs font-mono text-foreground">
                        {log.action}
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className="text-xs font-mono text-muted-foreground">
                        {log.device_hwid.substring(0, 12)}...
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className="text-xs font-mono text-muted-foreground">
                        {log.ip_address}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`font-mono text-xs ${
                          log.success
                            ? "bg-primary/15 text-primary border-primary/30"
                            : "bg-destructive/15 text-destructive border-destructive/30"
                        }`}
                      >
                        {log.success ? "OK" : "FAIL"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
