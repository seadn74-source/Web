import crypto from "crypto"

export function generateKey(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
  const segments: string[] = []
  for (let s = 0; s < 5; s++) {
    let segment = ""
    for (let i = 0; i < 5; i++) {
      const randomIndex = crypto.randomInt(0, chars.length)
      segment += chars[randomIndex]
    }
    segments.push(segment)
  }
  return segments.join("-")
}

export function generateSessionToken(): string {
  return crypto.randomBytes(48).toString("hex")
}
