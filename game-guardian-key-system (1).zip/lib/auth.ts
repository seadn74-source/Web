import { cookies } from "next/headers"
import { getDb } from "./db"

export async function getAdminSession() {
  const cookieStore = await cookies()
  const sessionToken = cookieStore.get("admin_session")?.value
  if (!sessionToken) return null

  const sql = getDb()
  const rows = await sql`
    SELECT s.id, s.admin_id, a.username 
    FROM admin_sessions s 
    JOIN admin_users a ON s.admin_id = a.id 
    WHERE s.session_token = ${sessionToken} 
    AND s.expires_at > NOW()
  `
  
  if (rows.length === 0) return null
  return { id: rows[0].admin_id, username: rows[0].username }
}
