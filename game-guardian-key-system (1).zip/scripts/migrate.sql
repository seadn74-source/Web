-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Keys table
CREATE TABLE IF NOT EXISTS keys (
  id SERIAL PRIMARY KEY,
  key_value VARCHAR(64) UNIQUE NOT NULL,
  device_hwid VARCHAR(255) DEFAULT NULL,
  status VARCHAR(20) DEFAULT 'unused' CHECK (status IN ('unused', 'active', 'expired', 'banned')),
  note TEXT DEFAULT '',
  duration_days INTEGER DEFAULT 30,
  activated_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Key logs table
CREATE TABLE IF NOT EXISTS key_logs (
  id SERIAL PRIMARY KEY,
  key_value VARCHAR(64) NOT NULL,
  device_hwid VARCHAR(255) NOT NULL,
  action VARCHAR(50) NOT NULL,
  ip_address VARCHAR(45) DEFAULT NULL,
  success BOOLEAN DEFAULT FALSE,
  message TEXT DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_keys_key_value ON keys(key_value);
CREATE INDEX IF NOT EXISTS idx_keys_device_hwid ON keys(device_hwid);
CREATE INDEX IF NOT EXISTS idx_keys_status ON keys(status);
CREATE INDEX IF NOT EXISTS idx_key_logs_key_value ON key_logs(key_value);
CREATE INDEX IF NOT EXISTS idx_key_logs_created_at ON key_logs(created_at);

-- Admin sessions table
CREATE TABLE IF NOT EXISTS admin_sessions (
  id SERIAL PRIMARY KEY,
  session_token VARCHAR(255) UNIQUE NOT NULL,
  admin_id INTEGER REFERENCES admin_users(id) ON DELETE CASCADE,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(session_token);

ALTER TABLE licenses ADD COLUMN hwid TEXT;
ALTER TABLE licenses ADD COLUMN banned BOOLEAN DEFAULT false;
ALTER TABLE licenses ADD COLUMN last_ip TEXT;
ALTER TABLE licenses ADD COLUMN verify_count INTEGER DEFAULT 0;