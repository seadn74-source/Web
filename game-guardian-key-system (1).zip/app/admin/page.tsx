"use client"

import { useEffect, useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Terminal, LogOut, Key, ScrollText, Code, RefreshCw } from "lucide-react"
import { toast } from "sonner"
import { StatsCards } from "@/components/admin/stats-cards"
import { KeyGenerator } from "@/components/admin/key-generator"
import { KeysTable } from "@/components/admin/keys-table"
import { LogsTable } from "@/components/admin/logs-table"
import { ScriptPanel } from "@/components/admin/script-panel"

interface Stats {
  total_keys: number
  active_keys: number
  unused_keys: number
  expired_keys: number
  banned_keys: number
  total_verifications: number
  recent_activity: number
}

export default function AdminDashboard() {
  const router = useRouter()
  const [stats, setStats] = useState<Stats | null>(null)
  const [keys, setKeys] = useState([])
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchData = useCallback(async () => {
    try {
      const [statsRes, keysRes, logsRes] = await Promise.all([
        fetch("/api/admin/stats"),
        fetch("/api/admin/keys"),
        fetch("/api/admin/logs"),
      ])

      if (statsRes.status === 401 || keysRes.status === 401) {
        router.push("/admin/login")
        return
      }

      const statsData = await statsRes.json()
      const keysData = await keysRes.json()
      const logsData = await logsRes.json()

      if (statsData.success) setStats(statsData.stats)
      if (keysData.success) setKeys(keysData.keys)
      if (logsData.success) setLogs(logsData.logs)
    } catch {
      toast.error("Failed to load data")
    } finally {
      setLoading(false)
    }
  }, [router])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  async function handleKeyAction(id: number, action: string) {
    try {
      if (action === "delete") {
        const res = await fetch("/api/admin/keys", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id }),
        })
        const data = await res.json()
        if (data.success) {
          toast.success("Key deleted")
          fetchData()
        }
      } else {
        const res = await fetch("/api/admin/keys", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, action }),
        })
        const data = await res.json()
        if (data.success) {
          toast.success(`Action "${action}" completed`)
          fetchData()
        }
      }
    } catch {
      toast.error("Action failed")
    }
  }

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" })
    router.push("/admin/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <RefreshCw className="w-6 h-6 text-primary animate-spin" />
          <p className="text-sm font-mono text-muted-foreground">Loading panel...</p>
        </div>
      </div>
    )
  }

  const baseUrl = typeof window !== "undefined" ? window.location.origin : ""

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/40 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 border border-primary/20">
              <Terminal className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold font-mono text-foreground tracking-tight">
                GG PANEL
              </h1>
              <p className="text-xs text-muted-foreground font-mono hidden sm:block">
                Key Management System
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => fetchData()}
              className="font-mono text-xs"
            >
              <RefreshCw className="w-3.5 h-3.5 mr-1" />
              Refresh
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="font-mono text-xs text-destructive hover:text-destructive"
            >
              <LogOut className="w-3.5 h-3.5 mr-1" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 flex flex-col gap-6">
        <StatsCards stats={stats} />

        <Tabs defaultValue="keys" className="w-full">
          <TabsList className="bg-card/60 border border-border/50">
            <TabsTrigger value="keys" className="font-mono text-xs gap-1.5">
              <Key className="w-3.5 h-3.5" />
              Keys
            </TabsTrigger>
            <TabsTrigger value="logs" className="font-mono text-xs gap-1.5">
              <ScrollText className="w-3.5 h-3.5" />
              Logs
            </TabsTrigger>
            <TabsTrigger value="script" className="font-mono text-xs gap-1.5">
              <Code className="w-3.5 h-3.5" />
              Script
            </TabsTrigger>
          </TabsList>

          <TabsContent value="keys" className="flex flex-col gap-4 mt-4">
            <KeyGenerator onKeysGenerated={fetchData} />
            <KeysTable keys={keys} onAction={handleKeyAction} />
          </TabsContent>

          <TabsContent value="logs" className="mt-4">
            <LogsTable logs={logs} />
          </TabsContent>

          <TabsContent value="script" className="mt-4">
            <ScriptPanel baseUrl={baseUrl} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
