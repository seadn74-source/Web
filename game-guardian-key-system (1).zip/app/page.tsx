"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Shield,
  Key,
  CheckCircle2,
  XCircle,
  Terminal,
  Loader2,
} from "lucide-react"

interface VerifyResult {
  success: boolean
  message: string
  expires_at?: string
}

export default function HomePage() {
  const [key, setKey] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<VerifyResult | null>(null)

  async function checkKey(e: React.FormEvent) {
    e.preventDefault()
    if (!key.trim()) return

    setLoading(true)
    setResult(null)

    try {
      const res = await fetch("/api/gg/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: key.trim(), hwid: "web-checker" }),
      })

      const data = await res.json()
      setResult(data)
    } catch {
      setResult({ success: false, message: "Connection error" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/40 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 border border-primary/20">
            <Terminal className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold font-mono text-foreground tracking-tight">
              GG KEY SYSTEM
            </h1>
            <p className="text-xs text-muted-foreground font-mono">
              Game Guardian Key Verification
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-lg flex flex-col gap-6">
          {/* Hero */}
          <div className="text-center flex flex-col gap-2">
            <div className="flex justify-center mb-2">
              <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20">
                <Shield className="w-8 h-8 text-primary" />
              </div>
            </div>
            <h2 className="text-2xl font-bold font-mono text-foreground">
              Key Verification
            </h2>
            <p className="text-sm text-muted-foreground max-w-sm mx-auto">
              Enter your key below to check its status. Each key is bound to one
              device only.
            </p>
          </div>

          {/* Key Checker */}
          <Card className="border-border/50 bg-card/80 backdrop-blur">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base font-mono">
                <Key className="w-4 h-4 text-primary" />
                Check Key Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={checkKey} className="flex flex-col gap-3">
                <Input
                  value={key}
                  onChange={(e) => setKey(e.target.value.toUpperCase())}
                  placeholder="XXXXX-XXXXX-XXXXX-XXXXX-XXXXX"
                  className="bg-secondary/50 border-border font-mono text-center tracking-wider"
                  maxLength={29}
                />
                <Button
                  type="submit"
                  disabled={loading || !key.trim()}
                  className="font-mono font-semibold"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Checking...
                    </>
                  ) : (
                    "VERIFY KEY"
                  )}
                </Button>
              </form>

              {result && (
                <div
                  className={`mt-4 rounded-lg border p-4 flex items-start gap-3 ${
                    result.success
                      ? "border-primary/30 bg-primary/5"
                      : "border-destructive/30 bg-destructive/5"
                  }`}
                >
                  {result.success ? (
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                  )}
                  <div className="flex flex-col gap-1">
                    <p
                      className={`text-sm font-mono font-semibold ${
                        result.success ? "text-primary" : "text-destructive"
                      }`}
                    >
                      {result.success ? "KEY VALID" : "KEY INVALID"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {result.message}
                    </p>
                    {result.expires_at && (
                      <p className="text-xs text-muted-foreground">
                        {"Expires: "}
                        {new Date(result.expires_at).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Features */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "1 Key = 1 Device", icon: Shield },
              { label: "HWID Lock", icon: Key },
              { label: "Anti-Share", icon: Terminal },
            ].map((feat) => (
              <div
                key={feat.label}
                className="flex flex-col items-center gap-2 p-3 rounded-lg bg-card/60 border border-border/30"
              >
                <feat.icon className="w-4 h-4 text-primary" />
                <span className="text-xs font-mono text-muted-foreground text-center">
                  {feat.label}
                </span>
              </div>
            ))}
          </div>

          {/* API Info */}
          <div className="text-center">
            <Badge variant="outline" className="font-mono text-xs border-border/50 text-muted-foreground">
              API v1.0 - ACTIVE
            </Badge>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 py-4">
        <p className="text-center text-xs text-muted-foreground font-mono">
          GG Key System - Secure Key Management
        </p>
      </footer>
    </div>
  )
}
