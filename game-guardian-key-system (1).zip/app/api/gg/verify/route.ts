import { NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

const TOKEN_SECRET = process.env.TOKEN_SECRET!

function signToken(key:string, hwid:string){
  return crypto.createHash("sha256")
    .update(key+"|"+hwid+"|"+TOKEN_SECRET)
    .digest("hex")
}

export async function POST(req:NextRequest){
  const { key, hwid, token } = await req.json()

  const valid = signToken(key, hwid)

  if(valid !== token){
    return NextResponse.json({ success:false })
  }

  return NextResponse.json({ success:true })
}