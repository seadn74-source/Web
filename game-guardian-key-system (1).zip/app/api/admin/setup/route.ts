import { NextRequest, NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import crypto from "crypto"

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

// One-time setup endpoint - creates admin account if none exists
export async function POST(request: NextRequest) {
  try {
    const sql = getDb()
    
    // Check if any admin already exists
    const admins = await sql`SELECT COUNT(*) as count FROM admin_users`
    if (Number(admins[0].count) > 0) {
      return NextResponse.json(
        { success: false, message: "Admin already exists. Setup is disabled." },
        { status: 403 }
      )
    }

    const { username, password } = await request.json()

    if (!username || !password || password.length < 8) {
      return NextResponse.json(
        { success: false, message: "Username required and password must be at least 8 characters" },
        { status: 400 }
      )
    }

    const passwordHash = hashPassword(password)
    await sql`INSERT INTO admin_users (username, password_hash) VALUES (${username}, ${passwordHash})`

    return NextResponse.json({ success: true, message: "Admin account created successfully" })
  } catch {
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    )
  }
}
