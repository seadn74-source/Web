import { NextRequest, NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import { getAdminSession } from "@/lib/auth"
import { generateKey } from "@/lib/keys"

// GET - List all keys
export async function GET() {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
  }

  const sql = getDb()
  const keys = await sql`SELECT * FROM keys ORDER BY created_at DESC`
  return NextResponse.json({ success: true, keys })
}

// POST - Generate new keys
export async function POST(request: NextRequest) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
  }

  try {
    const { count = 1, duration_days = 30, note = "" } = await request.json()
    const sql = getDb()
    const generatedKeys: string[] = []

    for (let i = 0; i < Math.min(count, 100); i++) {
      const keyValue = generateKey()
      await sql`INSERT INTO keys (key_value, duration_days, note) VALUES (${keyValue}, ${duration_days}, ${note})`
      generatedKeys.push(keyValue)
    }

    return NextResponse.json({ success: true, keys: generatedKeys })
  } catch {
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    )
  }
}

// DELETE - Delete a key
export async function DELETE(request: NextRequest) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
  }

  try {
    const { id } = await request.json()
    const sql = getDb()
    await sql`DELETE FROM keys WHERE id = ${id}`
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    )
  }
}

// PATCH - Update key status (ban, unban, reset hwid)
export async function PATCH(request: NextRequest) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
  }

  try {
    const { id, action } = await request.json()
    const sql = getDb()

    if (action === "ban") {
      await sql`UPDATE keys SET status = 'banned' WHERE id = ${id}`
    } else if (action === "unban") {
      await sql`UPDATE keys SET status = 'active' WHERE id = ${id}`
    } else if (action === "reset_hwid") {
      await sql`UPDATE keys SET device_hwid = NULL, status = 'unused', activated_at = NULL, expires_at = NULL WHERE id = ${id}`
    }

    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    )
  }
}
