import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import { getAdminSession } from "@/lib/auth"

export async function GET() {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
  }

  const sql = getDb()
  const logs = await sql`SELECT * FROM key_logs ORDER BY created_at DESC LIMIT 200`
  return NextResponse.json({ success: true, logs })
}
