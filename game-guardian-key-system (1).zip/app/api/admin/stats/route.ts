import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import { getAdminSession } from "@/lib/auth"

export async function GET() {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
  }

  const sql = getDb()

  const totalKeys = await sql`SELECT COUNT(*) as count FROM keys`
  const activeKeys = await sql`SELECT COUNT(*) as count FROM keys WHERE status = 'active'`
  const unusedKeys = await sql`SELECT COUNT(*) as count FROM keys WHERE status = 'unused'`
  const expiredKeys = await sql`SELECT COUNT(*) as count FROM keys WHERE status = 'expired'`
  const bannedKeys = await sql`SELECT COUNT(*) as count FROM keys WHERE status = 'banned'`
  const totalVerifications = await sql`SELECT COUNT(*) as count FROM key_logs WHERE action LIKE '%verify%'`
  const recentLogs = await sql`SELECT COUNT(*) as count FROM key_logs WHERE created_at > NOW() - INTERVAL '24 hours'`

  return NextResponse.json({
    success: true,
    stats: {
      total_keys: Number(totalKeys[0].count),
      active_keys: Number(activeKeys[0].count),
      unused_keys: Number(unusedKeys[0].count),
      expired_keys: Number(expiredKeys[0].count),
      banned_keys: Number(bannedKeys[0].count),
      total_verifications: Number(totalVerifications[0].count),
      recent_activity: Number(recentLogs[0].count),
    },
  })
}
