import { NextRequest, NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import { generateSessionToken } from "@/lib/keys"
import crypto from "crypto"

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()

    if (!username || !password) {
      return NextResponse.json(
        { success: false, message: "Missing credentials" },
        { status: 400 }
      )
    }

    const sql = getDb()
    const passwordHash = hashPassword(password)

    const users = await sql`
      SELECT * FROM admin_users WHERE username = ${username} AND password_hash = ${passwordHash}
    `

    if (users.length === 0) {
      return NextResponse.json(
        { success: false, message: "Invalid credentials" },
        { status: 401 }
      )
    }

    const token = generateSessionToken()
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 7) // 7 day session

    await sql`INSERT INTO admin_sessions (session_token, admin_id, expires_at)
      VALUES (${token}, ${users[0].id}, ${expiresAt.toISOString()})`

    const response = NextResponse.json({ success: true, message: "Login successful" })
    response.cookies.set("admin_session", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      expires: expiresAt,
    })

    return response
  } catch {
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    )
  }
}
